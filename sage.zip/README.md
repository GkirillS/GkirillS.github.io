linux chmod +x deploy.desktop ++
macOS chmod +x deploy.desktop ++
