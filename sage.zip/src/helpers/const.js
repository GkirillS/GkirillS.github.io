export const CAPACITY_GE_ML = "მლ.";
export const CAPACITY_EN_ML = "ml.";
export const CURRENCY = "gel";
export const LANGUAGE = "en";
export const API_KITCHEN =
  "https://script.google.com/macros/s/AKfycbwLBNzfqJInNXzY-JsqpsjOl1BIqSfu_Jnv6kQiDQtbsxfaCDSLte3t4yRxDScqX8H3/exec";
export const API_BAR =
  "https://script.google.com/macros/s/AKfycbyZlTj99w8AlgmffrGvgV_V8_19xsyccaNPQl5-rKM3ahb_7Dc1Pu_jvlHbaOyF2QW5gQ/exec";
export const API_SPECIAL =
  "https://script.google.com/macros/s/AKfycbz9Be2ggfyIhntQfnD6GG89FPkDVt9ngm26qrj3di7B1IBLW1E-jyY2BvP2WvDre8ztJA/exec";
