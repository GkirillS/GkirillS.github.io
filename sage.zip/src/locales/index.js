import ge from './ge.json';
import ru from './ru.json';
import en from './en.json';
export const LOCALES = {
	en,
	ru,
	ge
}